<?php

// Use Composer's autoloader for the tests
require_once __DIR__ . '/../vendor/autoload.php';

require_once __DIR__ . '/../src/voldemort-client.php';
