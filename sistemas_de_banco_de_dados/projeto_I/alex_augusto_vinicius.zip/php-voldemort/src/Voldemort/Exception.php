<?php

namespace Voldemort;

class Exception extends \Exception
{
}
